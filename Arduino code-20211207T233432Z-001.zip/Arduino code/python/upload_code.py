import serial
import mysql.connector
import time
import mysql

conn = mysql.connector.connect(host="localhost", user="root", password="", database="gro_data")
# open a cursor to the database
cursor = conn.cursor()

device = 'COM4'
try:
    print("Trying...", device)
    arduino = serial.Serial(port = device, baudrate=115200, timeout = 1)
except:
    print("Failed to connect on", device)

while True:
    try:
        time.sleep(0.1)
        data = arduino.readline()  # read the data from the arduino
        print(data)
        datastr = data.decode()
        datastripped = datastr.strip()
        pieces = datastripped.split(" ")  # split the data by the tab
        try:
            cursor.execute("INSERT INTO trash_test (ID, sensor1,sensor2) VALUES (13587987, %s,%s)", (pieces[0], pieces[1]))

            conn.commit()  # commit the insert
            cursor.close()  # close the cursor
        except mysql.connector.IntegrityError as err:
            print("failed to insert data")
        finally:
            cursor.close()  #close just incase it failed
    except:
        print("Failed to get data from Arduino!")






